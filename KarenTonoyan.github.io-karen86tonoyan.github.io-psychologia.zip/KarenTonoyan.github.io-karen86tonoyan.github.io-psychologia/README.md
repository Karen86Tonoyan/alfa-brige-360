psychologia pomoc ludz
<!DOCTYPE html>
<html>
  <head>
    <title>404 - Strona nie znaleziona</title>
  </head>
  <body>
    <h1>404 - Strona nie znaleziona</h1>
    <p>Przepraszamy, ale ta strona nie istnieje.</p>
    <a href="/">Powrót na stronę główną</a>
  </body>Karen Tonoyan
</html>
juz nie bawem  nowe ksiazki dla duszy i głowy 