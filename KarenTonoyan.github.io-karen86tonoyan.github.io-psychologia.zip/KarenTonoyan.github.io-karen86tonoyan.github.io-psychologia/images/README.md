# Placeholder for photo gallery
# Add your own photos here: photo1.jpg, photo2.jpg, photo3.jpg
# Images should be web-optimized (JPEG or PNG format)